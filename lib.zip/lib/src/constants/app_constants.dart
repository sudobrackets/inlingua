class AppConstants {
  static const String PLUS = 'plus';
  static const String MINUS = 'minus';
}
