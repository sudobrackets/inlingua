class AppConfig {
  static String baseURL = 'https://inlingua.languagestation.org/api/';
}
