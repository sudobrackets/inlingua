import 'package:flutter/material.dart';

class AppColors {
//App Default Colors
  static const Color postiveColor = Color(0xFF34D178);

  static const Color negativeColor = Color.fromRGBO(230, 38, 30, 1);
}
